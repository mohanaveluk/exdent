﻿<#
.SYNOPSIS
    Installs or updates the BixanaCloudSync Windows service
.DESCRIPTION
    This script will:
    - Check for existing service
    - Remove if exists
    - Install new service with specified parameters
    - Start the service
.NOTES
    File Name      : Install-BixanaCloudSync.ps1
    Prerequisite   : PowerShell 5.1+, Run as Administrator
#>

# Configuration
$serviceName = "BixanaCloudSync"
$binPath = "C:\SyncOpendentalData\BixanaCloudSync\BixanaCloudSync.exe"
$displayName = "Bixana.Cloud.Sync"
$description = "Service to sync the clinical data to cloud"
$startupType = "delayed-auto"

# Check if running as Administrator
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Warning "Please run this script as Administrator!"
    Read-Host "Press Enter to exit"
    exit 1
}

# Function to check if service exists
function Test-ServiceExists {
    param([string]$serviceName)
    try {
        $null = Get-Service -Name $serviceName -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

# Main installation process
try {
    Write-Host "`n=== BixanaCloudSync Service Installation ===" -ForegroundColor Cyan
    
    # Check and remove existing service
    if (Test-ServiceExists -serviceName $serviceName) {
        Write-Host "Found existing service. Removing it..." -ForegroundColor Yellow
        
        $service = Get-Service -Name $serviceName
        if ($service.Status -eq 'Running') {
            Write-Host "Stopping service..."
            Stop-Service -Name $serviceName -Force
            Start-Sleep -Seconds 3  # Give it time to stop
        }
        
        Write-Host "Deleting service..."
        sc.exe delete $serviceName | Out-Null
        Start-Sleep -Seconds 2  # Give it time to delete
        
        # Verify deletion
        if (Test-ServiceExists -serviceName $serviceName) {
            throw "Failed to remove existing service!"
        }
        Write-Host "Existing service removed successfully." -ForegroundColor Green
    }
    
    # Create new service
    Write-Host "`nInstalling new service..." -ForegroundColor Cyan
    $scArgs = @(
        "create", 
        "`"$serviceName`"",
        "binPath= `"$binPath`"",
        "start= $startupType",
        "DisplayName= `"$displayName`""
    )
    $scCreateArgs = @(
        "create",
        "`"$serviceName`"",
        "binPath=`"$binPath`"",    # NO space after equals here
        "start=$startupType",      # NO space after equals here
        "DisplayName=`"$displayName`""
    )

    
    sc.exe $scCreateArgs
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to create service (SC error $LASTEXITCODE)"
    }
    
    # Set description
    sc.exe description $serviceName "`"$description`"" | Out-Null
    
    # Start the service
    Write-Host "Starting service..."
    Start-Service -Name $serviceName
    Start-Sleep -Seconds 2  # Give it time to start
    
    # Verify installation
    $service = Get-Service -Name $serviceName
    Write-Host "`nService installed successfully!" -ForegroundColor Green
    Write-Host "Name:        $($service.Name)"
    Write-Host "DisplayName: $($service.DisplayName)"
    Write-Host "Status:      $($service.Status)"
    Write-Host "StartType:   $($service.StartType)"
    
} catch {
    Write-Host "`nERROR: $_" -ForegroundColor Red
    exit 1
}

Write-Host "`nInstallation completed." -ForegroundColor Green
Read-Host "Press Enter to exit"